
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-eaQ6ILPI6ZB26DxPvoPJ2V6ZjpUAMIIQTwL9kHGtS4MopfJSRgdd2Fq4FfB8vM8A"
        crossorigin="anonymous"></script>